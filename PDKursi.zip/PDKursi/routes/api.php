<?php

use App\Http\Controllers\CourseController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::post('/courses', [CourseController::class, 'store']); // Store - pievieno jaunu kursu datu bāzē
Route::get('/courses', [CourseController::class, 'index']); // Index - atgriež visus kursus
