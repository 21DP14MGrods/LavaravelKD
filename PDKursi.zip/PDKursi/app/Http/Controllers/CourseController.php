<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CourseController extends Controller
{
    /**
     * Store a newly created course in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nosaukums' => 'required|string|max:255',
            'paskaidrojosa_teksts' => 'required|string',
            'banera_adrese' => 'required|url',
            'cilveku_skaits' => 'required|integer|min:0',
        ]);

        $course = Course::all();
        return response()->json(['message' => 'Kurss veiksmīgi pievienots!', 'data' => $course], 201);
    }

    /**
     * Display a listing of the courses.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $course = Course::all();

        return response()->json($course);
    }
}
